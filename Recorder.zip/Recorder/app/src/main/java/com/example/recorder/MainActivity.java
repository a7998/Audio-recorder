package com.example.recorder;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import android.support.v7.app.ActionBarActivity;
import android.os.bundle;
import android.view.Menu;
import android.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Environment;
import android.widget.button;
import android.view.View;
import android.media.MediaPlayer;
import android.widget.SeekBar.OnSeekBarChangeListener;


public class MainActivity extends AppCompatActivity {


    private static MediaRecorder mr;
    private static MediaPlayer mp;
    private static String audiofilepath;
    private static Button record;
    private static Button stop;
    private static Button play;
    private boolean isrecording=false;
    private Handler mHandler;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        record=(Button)findViewById(R.id.record);
        stop=(Button)findViewById(R.id.stop);
        play=(Button)findViewById(R.id.play);
        seek=(SeekBar)findViewByid(R.id.seekBar);


        if(!hasMicrophone())
        {
            record.setEnabled(false);
            stop.setEnabled(false);
            play.setEnabled(false);
        }
        else {
            play.setEnabled(false);
            record.setEnabled(true);
        }
        audiofilepath=Environment.getExternalStorageDirectory().getAbsolutePath() + "/myaudio.mp3"


    }
    mr=new MediaRecorder();
    mr.setAudioSource(MediaRecorder.AudioSource.MIC);
    mr.setOutputFormat(MediaRecorder.OutputFormat.mp3);
    mr.setAudioEncoder(MediaRecorder.AudioEncoder.LAME);
    mp=new MediaPlayer();
    seek.setMax(mFileDuration/1000);
    private Handler mHandler = new Handler();

    MainActivity.this.runOnUiThread(new Runnable() {

        @Override
        public void run() {
            if(mp != null){
                int mCurrentPosition = mp.getCurrentPosition() / 1000;
                seek.setProgress(mCurrentPosition);
            }
            mHandler.postDelayed(this, 1000);
        }
    });
    mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            if(mp != null && fromUser){
                mp.seekTo(progress * 1000);
            }
        }
    });

    record.setOnclicklistener(new OnClicklistener())
    {
        @Override
                public void OnClick(View v)
        {
            mr.prepare();
            mr.start();
        }

    }
    stop.setOnClicklistener(new OnClicklistener())
    {
        @Override
             public void OnClick(View v)
        {
            mr.stop();
        }
    }
    play.setOnClicklistener(new OnClicklistener())
    {
        @Override
                public void OnClick(View v)
        {
            mp.DataSource("http://www.xyz.com/myaudio.mp3");
            mp.prepare();
            mp.start();
        }
    }

}